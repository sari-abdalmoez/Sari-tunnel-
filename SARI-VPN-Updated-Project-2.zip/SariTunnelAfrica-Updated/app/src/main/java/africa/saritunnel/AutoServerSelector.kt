package africa.saritunnel

import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.withContext
import java.net.Socket
import java.net.SocketTimeoutException
import java.util.concurrent.TimeUnit

/**
 * Performs intelligent server selection with connectivity testing.
 * Tests TCP connection latency to candidate servers.
 */
class AutoServerSelector {

    data class ServerCandidate(
        val profile: VlessSubscriptionManager.VlessProfile,
        val latency: Long = -1,
        val isReachable: Boolean = false
    )

    /**
     * Select a promising server from candidates using TCP latency checks.
     * Returns the server with the best latency, or null if no servers are reachable.
     */
    suspend fun selectBestServer(
        candidates: List<VlessSubscriptionManager.VlessProfile>,
        maxCandidates: Int = 10,
        tcpTimeout: Int = 5_000
    ): VlessSubscriptionManager.VlessProfile? = withContext(Dispatchers.Default) {
        if (candidates.isEmpty()) return@withContext null

        // Test a limited number of candidates to avoid excessive battery drain
        val toTest = candidates.take(maxCandidates)

        // Test all candidates concurrently
        val tested = toTest.map { profile ->
            async(Dispatchers.IO) {
                val latency = testTcpConnection(profile.host ?: return@async -1, profile.port, tcpTimeout)
                ServerCandidate(profile, latency, latency >= 0)
            }
        }.awaitAll()

        // Filter reachable servers and sort by latency
        val reachable = tested.filter { it.isReachable }.sortedBy { it.latency }

        return@withContext reachable.firstOrNull()?.profile
    }

    /**
     * Test TCP connection latency to a host:port.
     * Returns latency in milliseconds, or -1 if unreachable.
     */
    private fun testTcpConnection(host: String, port: Int, timeoutMs: Int): Long {
        if (host.isBlank() || port !in 1..65535) return -1

        var socket: Socket? = null
        val startTime = System.currentTimeMillis()

        return try {
            socket = Socket()
            socket.soTimeout = timeoutMs
            socket.connect(java.net.InetSocketAddress(host, port), timeoutMs)

            val elapsed = System.currentTimeMillis() - startTime
            if (elapsed < 0 || elapsed > Int.MAX_VALUE) -1L else elapsed
        } catch (_: SocketTimeoutException) {
            -1L
        } catch (_: Exception) {
            -1L
        } finally {
            try { socket?.close() } catch (_: Exception) {}
        }
    }

    companion object {
        private const val DEFAULT_TCP_TIMEOUT = 5_000
        private const val MAX_CANDIDATES_TO_TEST = 10
    }
}
