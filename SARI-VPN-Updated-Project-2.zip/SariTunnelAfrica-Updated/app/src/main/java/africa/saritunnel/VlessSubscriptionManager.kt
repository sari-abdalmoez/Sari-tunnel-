package africa.saritunnel

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/**
 * Fetches and manages VLESS profiles from multiple subscription sources.
 * Supports caching and fallback when sources are unavailable.
 */
class VlessSubscriptionManager(private val context: Context) {
    private val cacheDir = File(context.cacheDir, "vless_profiles")
    private val prefs: SharedPreferences = context.getSharedPreferences("vless_subscriptions", Context.MODE_PRIVATE)

    data class VlessProfile(
        val id: String,
        val label: String,
        val uri: String,
        val country: String? = null,
        val host: String? = null,
        val port: Int = 0
    )

    init {
        if (!cacheDir.exists()) cacheDir.mkdirs()
    }

    /**
     * Fetch VLESS profiles from both primary and fallback sources.
     * Returns cached profiles if fetch fails and cache is available.
     */
    suspend fun fetchProfiles(): List<VlessProfile> = withContext(Dispatchers.IO) {
        val profiles = mutableMapOf<String, VlessProfile>()

        // Try primary source
        try {
            val primary = fetchFromUrl(PRIMARY_URL)
            primary.forEach { profiles[it.uri] = it }
        } catch (e: Exception) {
            // Log but continue to fallback
        }

        // Try fallback source
        try {
            val fallback = fetchFromUrl(FALLBACK_URL)
            fallback.forEach { profile ->
                profiles.putIfAbsent(profile.uri, profile)
            }
        } catch (e: Exception) {
            // Log but try cache
        }

        // If no profiles found from either source, try cache
        if (profiles.isEmpty()) {
            val cached = loadFromCache()
            return@withContext cached
        }

        // Save to cache for future use
        saveToCache(profiles.values.toList())

        return@withContext profiles.values.toList()
    }

    private fun fetchFromUrl(urlString: String): List<VlessProfile> {
        val connection = (URL(urlString).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 20_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120 Mobile")
        }

        return try {
            val code = connection.responseCode
            if (code !in 200..299) throw Exception("HTTP $code")

            val content = connection.inputStream.use { input ->
                val output = ByteArrayOutputStream()
                val buffer = ByteArray(8192)
                var total = 0
                while (true) {
                    val n = input.read(buffer)
                    if (n < 0) break
                    total += n
                    if (total > MAX_SUBSCRIPTION_SIZE) throw Exception("Subscription too large")
                    output.write(buffer, 0, n)
                }
                String(output.toByteArray(), Charsets.UTF_8)
            }

            parseVlessLinks(content)
        } finally {
            connection.disconnect()
        }
    }

    private fun parseVlessLinks(content: String): List<VlessProfile> {
        val profiles = mutableMapOf<String, VlessProfile>()
        val lines = content.split(Regex("[\\r\\n]+"))

        for (line in lines) {
            val trimmed = line.trim()
                .trimEnd(',', ';', ')', ']', '.')
                .takeIf { it.isNotBlank() } ?: continue

            if (!trimmed.startsWith("vless://", ignoreCase = true)) continue
            if (trimmed.contains("...") || trimmed.contains('…')) continue

            try {
                // Validate the VLESS URI
                val uri = Uri.parse(trimmed)
                val uuid = Uri.decode(uri.userInfo.orEmpty()).substringBefore(':').trim()
                val host = uri.host?.takeIf { it.isNotBlank() } ?: continue
                val port = uri.port

                if (uuid.isBlank() || port !in 1..65535) continue
                if (!trimmed.contains("@")) continue

                // Validate the configuration can be built
                try {
                    XrayConfigBuilder.fromVlessUri(trimmed)
                } catch (e: Exception) {
                    // Invalid config for our engine, skip
                    continue
                }

                // Generate label
                val label = uri.fragment?.let { Uri.decode(it) }?.takeIf { it.isNotBlank() }
                    ?: "$host:$port"

                val id = "vless-${profiles.size}"
                profiles.putIfAbsent(trimmed, VlessProfile(
                    id = id,
                    label = label,
                    uri = trimmed,
                    host = host,
                    port = port
                ))
            } catch (_: Exception) {
                // Skip malformed entries
                continue
            }
        }

        return profiles.values.toList()
    }

    private fun saveToCache(profiles: List<VlessProfile>) {
        try {
            val cacheFile = File(cacheDir, "profiles.txt")
            cacheFile.writeText(profiles.joinToString("\n") { it.uri })
            prefs.edit().putLong("cache_timestamp", System.currentTimeMillis()).apply()
        } catch (_: Exception) {
            // Silent fail for cache
        }
    }

    private fun loadFromCache(): List<VlessProfile> {
        return try {
            val cacheFile = File(cacheDir, "profiles.txt")
            if (!cacheFile.exists()) return emptyList()

            val lines = cacheFile.readLines()
            val profiles = mutableListOf<VlessProfile>()

            for ((index, uri) in lines.withIndex()) {
                if (uri.isBlank()) continue
                try {
                    val parsedUri = Uri.parse(uri)
                    val host = parsedUri.host ?: continue
                    val port = parsedUri.port
                    val label = parsedUri.fragment?.let { Uri.decode(it) }
                        ?: "$host:$port"

                    profiles.add(VlessProfile(
                        id = "cached-$index",
                        label = label,
                        uri = uri,
                        host = host,
                        port = port
                    ))
                } catch (_: Exception) {
                    continue
                }
            }
            profiles
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun clearCache() {
        try {
            val cacheFile = File(cacheDir, "profiles.txt")
            if (cacheFile.exists()) cacheFile.delete()
            prefs.edit().remove("cache_timestamp").apply()
        } catch (_: Exception) {
            // Silent fail
        }
    }

    companion object {
        private const val PRIMARY_URL = "https://raw.githubusercontent.com/rtwo2/FastNodes/main/sub/protocols/vless.txt"
        private const val FALLBACK_URL = "https://github.com/Epodonios/v2ray-configs/raw/main/All_Configs_Sub.txt"
        private const val MAX_SUBSCRIPTION_SIZE = 10 * 1024 * 1024 // 10 MB limit
    }
}
