package africa.saritunnel

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

/**
 * Periodic worker that updates VLESS subscriptions every 8 hours.
 */
class SubscriptionUpdateWorker(context: Context, params: androidx.work.WorkerParameters) :
    CoroutineWorker(context, params) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        return@withContext try {
            val manager = VlessSubscriptionManager(applicationContext)
            manager.fetchProfiles()
            Result.success()
        } catch (e: Exception) {
            // Retry if network is unavailable
            if (e.message?.contains("HTTP") == true || e.message?.contains("Connection") == true) {
                Result.retry()
            } else {
                Result.success() // Don't retry on parse errors
            }
        }
    }

    companion object {
        private const val WORK_TAG = "vless_subscription_update"

        fun schedulePeriodicUpdates(context: Context) {
            val updateRequest = PeriodicWorkRequestBuilder<SubscriptionUpdateWorker>(
                8, // interval
                TimeUnit.HOURS,
                1, // flex interval
                TimeUnit.HOURS
            )
                .addTag(WORK_TAG)
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_TAG,
                ExistingPeriodicWorkPolicy.KEEP,
                updateRequest
            )
        }

        fun cancelUpdates(context: Context) {
            WorkManager.getInstance(context).cancelAllWorkByTag(WORK_TAG)
        }
    }
}
