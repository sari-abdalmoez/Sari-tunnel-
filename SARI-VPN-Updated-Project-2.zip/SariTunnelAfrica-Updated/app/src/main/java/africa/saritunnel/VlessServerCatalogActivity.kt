package africa.saritunnel

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.net.VpnService
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.material.card.MaterialCardView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/** Loads and manages VLESS share URIs from configured subscription sources. */
class VlessServerCatalogActivity : AppCompatActivity() {
    data class Entry(val id: String, val label: String, val uri: String?)

    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var refresh: Button
    private var entries: List<Entry> = emptyList()
    private var pendingConfig: String? = null
    private lateinit var subscriptionManager: VlessSubscriptionManager

    private val consentLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val config = pendingConfig
        pendingConfig = null
        if (result.resultCode == RESULT_OK && !config.isNullOrBlank()) startXray(config)
        else if (!config.isNullOrBlank()) setStatus("Android VPN permission was not granted.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        subscriptionManager = VlessSubscriptionManager(this)
        setContentView(buildLayout())
        val savedStatus = getSharedPreferences("xray_state", MODE_PRIVATE).getString("status", null)
        if (!savedStatus.isNullOrBlank()) status.text = "VLESS status: $savedStatus"
        refreshFeed()
    }

    override fun onResume() {
        super.onResume()
        val state = getSharedPreferences("xray_state", MODE_PRIVATE).getString("status", null)
        if (!state.isNullOrBlank()) status.text = "VLESS status: $state"
    }

    private fun buildLayout(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setBackgroundColor(ContextCompat.getColor(this@VlessServerCatalogActivity, R.color.sari_background))
        }
        root.addView(TextView(this).apply {
            text = "SARI VPN · VLESS"
            textSize = 24f
            setTextColor(ContextCompat.getColor(this@VlessServerCatalogActivity, R.color.sari_text))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "Auto-updating subscription servers"
            textSize = 12f
            setPadding(0, dp(3), 0, dp(8))
            setTextColor(ContextCompat.getColor(this@VlessServerCatalogActivity, R.color.sari_muted))
        })
        status = TextView(this).apply {
            text = "Fetching profiles…"
            textSize = 13f
            setTextColor(ContextCompat.getColor(this@VlessServerCatalogActivity, R.color.sari_text))
            setPadding(0, dp(5), 0, dp(8))
        }
        root.addView(status)

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        refresh = Button(this).apply { text = "Refresh list"; setOnClickListener { refreshFeed() } }
        actions.addView(refresh, LinearLayout.LayoutParams(0, dp(46), 1f))
        actions.addView(Button(this).apply {
            text = "Disconnect VLESS"
            setOnClickListener {
                try {
                    startService(Intent(this@VlessServerCatalogActivity, XrayVpnService::class.java).setAction(XrayVpnService.ACTION_STOP))
                    setStatus("VLESS disconnect requested. If another VPN is active, disconnect it in its own app.")
                } catch (e: Exception) { setStatus("Could not request disconnect: ${e.message ?: "unknown error"}") }
            }
        }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginStart = dp(8) })
        root.addView(actions)

        progress = ProgressBar(this).apply { visibility = View.GONE; isIndeterminate = true }
        root.addView(progress, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(3)))
        root.addView(TextView(this).apply {
            text = "Android can run only one VPN at a time. Disconnect OpenVPN or any other VPN before starting VLESS."
            textSize = 12f
            setTextColor(ContextCompat.getColor(this@VlessServerCatalogActivity, R.color.sari_muted))
            setPadding(0, dp(8), 0, dp(10))
        })
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(Button(this).apply { text = "Back"; setOnClickListener { finish() } }, LinearLayout.LayoutParams(-1, dp(44)))
        return root
    }

    private fun refreshFeed() {
        progress.visibility = View.VISIBLE
        refresh.isEnabled = false
        setStatus("Fetching VLESS profiles from subscriptions…")
        lifecycleScope.launch {
            try {
                val profiles = withContext(Dispatchers.IO) { subscriptionManager.fetchProfiles() }
                if (profiles.isEmpty()) {
                    entries = emptyList()
                    renderEntries()
                    setStatus("No valid VLESS profiles found. Check connection and subscriptions.")
                } else {
                    entries = profiles.map { Entry(it.id, it.label, it.uri) }
                    renderEntries()
                    setStatus("Loaded ${profiles.size} valid VLESS profile(s).")
                }
            } catch (e: Exception) {
                entries = emptyList()
                renderEntries()
                setStatus("Could not fetch profiles: ${e.message ?: e.javaClass.simpleName}. Check connection and retry.")
            } finally {
                progress.visibility = View.GONE
                refresh.isEnabled = true
            }
        }
    }

    private fun renderEntries() {
        list.removeAllViews()
        if (entries.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "No VLESS profiles loaded. Tap Refresh to fetch from subscriptions."
                textSize = 13f
                setTextColor(ContextCompat.getColor(this@VlessServerCatalogActivity, R.color.sari_muted))
                setPadding(dp(10), dp(18), dp(10), dp(18))
            })
            return
        }
        entries.forEach { entry ->
            val card = MaterialCardView(this).apply {
                radius = dp(15).toFloat()
                cardElevation = 0f
                strokeWidth = dp(1)
                setStrokeColor(ContextCompat.getColor(this@VlessServerCatalogActivity, R.color.sari_surface_alt))
                setCardBackgroundColor(ContextCompat.getColor(this@VlessServerCatalogActivity, R.color.sari_surface))
                setContentPadding(dp(13), dp(12), dp(13), dp(12))
            }
            val column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            column.addView(TextView(this).apply {
                text = entry.label
                textSize = 15f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setTextColor(ContextCompat.getColor(this@VlessServerCatalogActivity, R.color.sari_text))
            })
            column.addView(TextView(this).apply {
                text = "VLESS · Xray engine"
                textSize = 12f
                setPadding(0, dp(4), 0, dp(8))
                setTextColor(ContextCompat.getColor(this@VlessServerCatalogActivity, R.color.sari_muted))
            })
            val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            if (entry.uri != null) {
                buttons.addView(Button(this@VlessServerCatalogActivity).apply {
                    text = "Connect"
                    setOnClickListener { requestConnect(entry.uri!!) }
                }, LinearLayout.LayoutParams(0, dp(44), 1f))
            }
            buttons.addView(Button(this@VlessServerCatalogActivity).apply {
                text = "Copy link"
                setOnClickListener { copy(entry.uri.orEmpty()) }
            }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(8) })
            column.addView(buttons)
            card.addView(column)
            list.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })
        }
    }

    private fun requestConnect(share: String) {
        val cfg = try { XrayConfigBuilder.fromVlessUri(share) } catch (e: Exception) {
            setStatus("This VLESS link cannot be used: ${e.message ?: "invalid profile"}")
            return
        }
        pendingConfig = cfg
        val consent = VpnService.prepare(this)
        if (consent == null) {
            pendingConfig = null
            startXray(cfg)
        } else consentLauncher.launch(consent)
    }

    private fun startXray(config: String) {
        try {
            ContextCompat.startForegroundService(
                this,
                Intent(this, XrayVpnService::class.java)
                    .setAction(XrayVpnService.ACTION_START)
                    .putExtra(XrayVpnService.EXTRA_CONFIG, config)
            )
            setStatus("Starting Xray. Disconnect any currently active VPN first if Android rejects the request.")
        } catch (e: Exception) {
            setStatus("Could not start VLESS engine: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private fun copy(text: String) {
        if (text.isBlank()) return
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Sari VPN server", text))
        Toast.makeText(this, "Copied to clipboard", Toast.LENGTH_SHORT).show()
    }

    private fun setStatus(message: String) {
        status.text = message
        getSharedPreferences("xray_state", MODE_PRIVATE).edit().putString("ui_status", message).apply()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    companion object {
        private const val TAG = "VlessServerCatalog"
    }
}
